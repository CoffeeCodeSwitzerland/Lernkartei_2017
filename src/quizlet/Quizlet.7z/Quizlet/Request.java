package Quizlet;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import org.json.*;


/**
 * Klasse um HTTP Requests auszuf�hren.
 * 
 * @author ma
 *
 */
public class Request
{
	public static String		charset	= "UTF-8";
	private static JSONObject	obj;

	/**
	 * F�hrt eine Get-Abfrage durch
	 * 
	 * @param url
	 *            Kompletter URL f�r die Abfrage. Muss korrekt sein, sonst wird
	 *            ein Fehler ausgel�st
	 * @return Antwort als JSON Object, null wenn es einen Fehler gibt
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public static JSONObject GetJSONObject (String url) throws MalformedURLException, IOException
	{
		// �ffnet die Verbindung
		URLConnection connection = new URL(url).openConnection();
		// Setzt die Charset Property
		connection.setRequestProperty("Accept-Charset", charset);
		// Speichert das Resultat
		InputStream response = connection.getInputStream();

		// Erzeugt das JSONObject und gibt es zur�ck
		try (Scanner scanner = new Scanner(response))
		{
			String responseBody = scanner.useDelimiter("\\A").next();
			obj = new JSONObject(responseBody);
			return obj;
		}
		catch (Exception e)
		{
			System.out.println("Error (Request):");
			System.out.println(e.getMessage());
			return null;
		}
	}

	/*
	public static void PostJSONObject (String url, String query) throws UnsupportedEncodingException, IOException
	{
		// TODO HTTP POST
		
		String uri = "https://quizlet.com/authorize";
		
		URLConnection connection = new URL(url).openConnection();
		connection.setDoOutput(true); // Triggers POST.
		connection.setRequestProperty("Accept-Charset", charset);
		connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=" + charset);

		
		try (OutputStream output = connection.getOutputStream()) {
		    output.write(query.getBytes(charset));
		}

		InputStream response = connection.getInputStream();
		
		HttpURLConnection httpConnection = (HttpURLConnection) new URL(url).openConnection();
		httpConnection.setRequestMethod("POST");
		// ...
		
		int status = httpConnection.getResponseCode();
		
//		for (Entry<String, List<String>> header : connection.getHeaderFields().entrySet()) {
//		    System.out.println(header.getKey() + "=" + header.getValue());
//		}
		
		String contentType = connection.getHeaderField("Content-Type");
		String charset = null;

		for (String param : contentType.replace(" ", "").split(";")) {
		    if (param.startsWith("charset=")) {
		        charset = param.split("=", 2)[1];
		        break;
		    }
		}

		if (charset != null) {
		    try (BufferedReader reader = new BufferedReader(new InputStreamReader(response, charset))) {
		        for (String line; (line = reader.readLine()) != null;) {
		            System.out.println(line);
		        }
		    }
		}
		else {
		    // It's likely binary content, use InputStream/OutputStream.
		}
		
//		
//		
//		CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));
//
//		
//		
//		// Gather all cookies on the first request.
//		URLConnection connection = new URL(url).openConnection();
//		List<String> cookies = connection.getHeaderFields().get("Set-Cookie");
//		// ...
//
//		// Then use the same cookies on all subsequent requests.
//		connection = new URL(url).openConnection();
//		for (String cookie : cookies) {
//		    connection.addRequestProperty("Cookie", cookie.split(";", 2)[0]);
//		}
		
	}
	*/
}
